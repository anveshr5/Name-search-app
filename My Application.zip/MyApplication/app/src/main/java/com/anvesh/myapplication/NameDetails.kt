package com.anvesh.myapplication

data class NameDetails(val name: String,val pos:Int)
